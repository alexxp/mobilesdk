//
//  TripleLiftSDK.h
//  TripleLiftSDK
//
//  Created by Alexander Prokofiev on 11/30/16.
//  Copyright © 2016 TripleLift. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TripleLiftSDK.
FOUNDATION_EXPORT double TripleLiftSDKVersionNumber;

//! Project version string for TripleLiftSDK.
FOUNDATION_EXPORT const unsigned char TripleLiftSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TripleLiftSDK/PublicHeader.h>


